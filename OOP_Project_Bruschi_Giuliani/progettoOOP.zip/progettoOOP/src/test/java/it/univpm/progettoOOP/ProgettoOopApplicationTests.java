package it.univpm.progettoOOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoOopApplicationTests {

	@Test
	void contextLoads() {
	}

}
